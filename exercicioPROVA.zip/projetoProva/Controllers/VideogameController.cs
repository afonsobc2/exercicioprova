using Microsoft.AspNetCore.Mvc;
using projetoProva.Models;

namespace projetoProva.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class VideogameController : ControllerBase
    {
        private BDContexto contexto;
        
        public VideogameController(BDContexto bdContexto)
        {
            contexto = bdContexto;
        }
        
        [HttpGet]
        public List<Videogame> Listar()
        {

        }

        [HttpGet]
        public List<Videogame> ListarPorFabricante(string fabricante)
        {
            
        }


        [HttpGet]
        public List<Videogame> Visualizar(int id)
        {
            
        }


        [HttpPost]
        public string Cadastrar([FromBody]Videogame dados)
        {
            
        }

        [HttpDelete]
        public string Excluir([FromBody]int id)
        {
            
        }
        
    }
}